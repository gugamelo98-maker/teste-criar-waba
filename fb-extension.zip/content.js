// Roda no painel (vercel.app) — escuta pedidos de cookies
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.source !== 'waba-manager') return;

  if (event.data.action === 'GET_FB_COOKIES') {
    chrome.runtime.sendMessage({ action: 'GET_FB_COOKIES' }, (response) => {
      window.postMessage({
        source: 'waba-extension',
        action: 'FB_COOKIES_RESULT',
        data: response
      }, '*');
    });
  }

  if (event.data.action === 'CHECK_FB_LOGIN') {
    chrome.runtime.sendMessage({ action: 'CHECK_FB_LOGIN' }, (response) => {
      window.postMessage({
        source: 'waba-extension',
        action: 'FB_LOGIN_STATUS',
        data: response
      }, '*');
    });
  }
});

// Avisa o painel que a extensão está instalada
window.postMessage({
  source: 'waba-extension',
  action: 'EXTENSION_READY'
}, '*');
