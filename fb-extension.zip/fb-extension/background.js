// Escuta mensagens do content script (painel vercel.app)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'GET_FB_COOKIES') {
    getFacebookCookies().then(sendResponse);
    return true; // mantém canal aberto para resposta assíncrona
  }
  if (msg.action === 'CHECK_FB_LOGIN') {
    checkFacebookLogin().then(sendResponse);
    return true;
  }
});

async function getFacebookCookies() {
  const domains = ['https://www.facebook.com', 'https://business.facebook.com'];
  const cookieNames = ['c_user', 'xs', 'datr', 'sb', 'fr', 'wd', 'locale', 'usida'];

  const result = {};

  for (const domain of domains) {
    for (const name of cookieNames) {
      if (result[name]) continue; // já capturou
      try {
        const cookie = await chrome.cookies.get({ url: domain, name });
        if (cookie) result[name] = cookie.value;
      } catch(e) {}
    }
  }

  // Monta cookie string no formato "name=value; name=value"
  const cookieStr = Object.entries(result).map(([k, v]) => `${k}=${v}`).join('; ');
  const isLoggedIn = !!result['c_user'];

  return {
    success: isLoggedIn,
    cookies: cookieStr,
    cookiesObj: result,
    userId: result['c_user'] || null,
    savedAt: Date.now()
  };
}

async function checkFacebookLogin() {
  try {
    const cookie = await chrome.cookies.get({
      url: 'https://www.facebook.com',
      name: 'c_user'
    });
    return { loggedIn: !!cookie, userId: cookie?.value || null };
  } catch(e) {
    return { loggedIn: false, userId: null };
  }
}
