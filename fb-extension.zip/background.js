// Escuta mensagens do content script (painel vercel.app)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'GET_FB_COOKIES') {
    getFacebookCookies(sender).then(sendResponse);
    return true;
  }
  if (msg.action === 'CHECK_FB_LOGIN') {
    checkFacebookLogin(sender).then(sendResponse);
    return true;
  }
});

async function getStoreId(sender) {
  // Se a mensagem veio de uma aba, usa o storeId dessa aba (funciona em anônimo também)
  if (sender && sender.tab && sender.tab.cookieStoreId) {
    return sender.tab.cookieStoreId;
  }
  // Fallback: busca todas as cookie stores e usa a default
  try {
    const stores = await chrome.cookies.getAllCookieStores();
    const incognito = stores.find(s => s.id === '1');
    const normal = stores.find(s => s.id === '0');
    return (incognito || normal || stores[0]).id;
  } catch(e) {
    return '0';
  }
}

async function getFacebookCookies(sender) {
  const storeId = await getStoreId(sender);
  const domains = ['https://www.facebook.com', 'https://business.facebook.com'];
  const cookieNames = ['c_user', 'xs', 'datr', 'sb', 'fr', 'wd', 'locale', 'usida'];

  const result = {};

  for (const domain of domains) {
    for (const name of cookieNames) {
      if (result[name]) continue;
      try {
        const cookie = await chrome.cookies.get({ url: domain, name, storeId });
        if (cookie) result[name] = cookie.value;
      } catch(e) {}
    }
  }

  const cookieStr = Object.entries(result).map(([k, v]) => `${k}=${v}`).join('; ');
  const isLoggedIn = !!result['c_user'];

  return {
    success: isLoggedIn,
    cookies: cookieStr,
    cookiesObj: result,
    userId: result['c_user'] || null,
    savedAt: Date.now()
  };
}

async function checkFacebookLogin(sender) {
  try {
    const storeId = await getStoreId(sender);
    const cookie = await chrome.cookies.get({
      url: 'https://www.facebook.com',
      name: 'c_user',
      storeId
    });
    return { loggedIn: !!cookie, userId: cookie?.value || null };
  } catch(e) {
    return { loggedIn: false, userId: null };
  }
}
